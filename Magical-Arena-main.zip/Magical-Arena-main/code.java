import java.util.Random;
import java.util.Scanner;

class Player {
    private int health;
    private int strength;
    private int attack;

    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getStrength() {
        return strength;
    }

    public int getAttack() {
        return attack;
    }
}

class MagicalArena {
    private Player playerA;
    private Player playerB;
    private Random random;

    public MagicalArena(Player playerA, Player playerB) {
        this.playerA = playerA;
        this.playerB = playerB;
        this.random = new Random();
    }

    public void fight() {
        Player attacker = playerA.getHealth() < playerB.getHealth() ? playerA : playerB;
        Player defender = attacker == playerA ? playerB : playerB;

        while (playerA.getHealth() > 0 && playerB.getHealth() > 0) {
            int attackRoll = random.nextInt(6) + 1;
            int defenseRoll = random.nextInt(6) + 1;

            int damageDealt = attackRoll * attacker.getAttack();
            int damageDefended = defenseRoll * defender.getStrength();

            int damageTaken = Math.max(0, damageDealt - damageDefended);
            defender.setHealth(defender.getHealth() - damageTaken);

            System.out.println(attacker == playerA ? "Player A" : "Player B" +
                               " attacks with roll " + attackRoll +
                               " and deals " + damageDealt +
                               " damage. Defender's roll: " + defenseRoll +
                               " and defends " + damageDefended +
                               " damage. Damage taken: " + damageTaken);

            // Swap attacker and defender for the next round
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        if (playerA.getHealth() <= 0) {
            System.out.println("Player B wins!");
        } else {
            System.out.println("Player A wins!");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get input for Player A
        System.out.println("Enter health, strength, and attack for Player A (space-separated):");
        int playerAHealth = scanner.nextInt();
        int playerAStrength = scanner.nextInt();
        int playerAAttack = scanner.nextInt();

        // Get input for Player B
        System.out.println("Enter health, strength, and attack for Player B (space-separated):");
        int playerBHealth = scanner.nextInt();
        int playerBStrength = scanner.nextInt();
        int playerBAttack = scanner.nextInt();

        scanner.close();

        Player playerA = new Player(playerAHealth, playerAStrength, playerAAttack);
        Player playerB = new Player(playerBHealth, playerBStrength, playerBAttack);

        MagicalArena arena = new MagicalArena(playerA, playerB);
        arena.fight();
    }
}
